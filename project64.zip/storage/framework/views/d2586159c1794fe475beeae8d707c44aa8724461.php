

<?php $__env->startSection('body'); ?>
<div class="container">
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Manage Student Submit Info</li>
</ol>
<?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead class="bg-primary text-white">
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Union</th>
              <th>Channel</th>
              <th>Link</th>
              <th>Watch Time</th>
              <th>Total Sub</th>
              <th>Total View</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Union</th>
              <th>Channel</th>
              <th>Link</th>
              <th>Watch Time</th>
              <th>Total Sub</th>
              <th>Total View</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php ($i = 1); ?>
          <?php $__currentLoopData = $sInfos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><?php echo e($sInfo->name); ?></td>
              <td><?php echo e($sInfo->phone); ?></td>
              <td><?php echo e($sInfo->union); ?></td>
              <td><?php echo e($sInfo->channel); ?></td>
              <td><?php echo e($sInfo->link); ?></td>
              <td><?php echo e($sInfo->watch_time); ?></td>
              <td><?php echo e($sInfo->total_sub); ?></td>
              <td><?php echo e($sInfo->total_view); ?></td>
              <td>
                  <form action="<?php echo e(route("admin.student-submit-info.destroy",['student_submit_info' => $sInfo->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field("DELETE"); ?>
                      <button class="btn-circle btn-danger" type="submit" onclick="return confirm('Are your sure')"><span class="fa fa-trash"></span></button>
                  </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/submit-info/manage-submit-info.blade.php ENDPATH**/ ?>