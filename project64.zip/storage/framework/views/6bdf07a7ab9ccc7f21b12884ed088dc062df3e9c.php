

<?php $__env->startSection('body'); ?>
<div class="container">
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Manage student</li>
</ol>
<?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
      <div class="col-lg-4">
          <div class="card-body border border-primary">
            <div class="alert alert-dark">Search By Student Email</div>
            <form action="<?php echo e(route("admin.search-register-student")); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <input type="search" name="email" class="form-control" placeholder="Enter Email..." id="" required>
            </form>
          </div>
      </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead class="bg-primary text-white">
            <tr>
              <th>No</th>
              <th>Student Name</th>
              <th>Refer Code</th>
              <th>Email</th>
              <th>Channel</th>
              <th>Image</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Student Name</th>
              <th>Refer Code</th>
              <th>Email</th>
              <th>Channel</th>
              <th>Image</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php ($i = 1); ?>
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><?php echo e($student->name); ?></td>
              <td><?php echo e($student->refer_code); ?></td>
              <td><?php echo e($student->email); ?></td>
              <td><?php echo e($student->channel); ?></td>
              <td><img src="<?php echo e(asset($student->photo)); ?>" width="80" alt=""></td>
              <td>
                <form action="<?php echo e(route("admin.student-register.update", ['student_register' => $student->id])); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                        <select name="status" id="">
                        <option value="<?php echo e($student->status); ?>"><?php echo e($student->status); ?></option>
                        <option value="Success">Success</option>
                        <option value="Pending">Pending</option>
                    </select>
                    <hr>
                    <input class="btn btn-primary btn-sm btn-block" type="submit" name="update" value="Update" >
                  </form>
              </td>
              <td>
                <form action="<?php echo e(route("admin.student-register.destroy",['student_register' => $student->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field("DELETE"); ?>
                      <button class="btn-circle btn-danger" type="submit" onclick="return confirm('Are your sure')"><span class="fa fa-trash"></span></button>
                  </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/student-register/manage-student-register.blade.php ENDPATH**/ ?>