

<?php $__env->startSection('title'); ?>
    HOME - PROFILE
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-3">
                     <?php if (isset($component)) { $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentDashboard::class, []); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('student-dashboard'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d)): ?>
<?php $component = $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d; ?>
<?php unset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-9">
                    <div class="shadow rounded bg-white text-dark p-5">
                        <form action="<?php echo e(route("update-password")); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
                            <div class="form-group row">
                                <label for="old" class="col-lg-3">Old Password</label>
                                <div class="col-lg-9">
                                    <input type="password" class="form-control" name="old_password" id="old" required>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="new" class="col-lg-3">New Password</label>
                                <div class="col-lg-9">
                                    <input type="password" class="form-control" name="new_password" id="new" required>
                                </div>
                            </div>
                            <input type="submit" value="Update Password" class="btn btn-primary form-control">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/password/change-password.blade.php ENDPATH**/ ?>