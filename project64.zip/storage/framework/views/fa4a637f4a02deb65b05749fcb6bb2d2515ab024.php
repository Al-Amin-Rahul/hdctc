

<?php $__env->startSection('title'); ?>
    HOME - Completed Sheet
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-3">
                     <?php if (isset($component)) { $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentDashboard::class, []); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('student-dashboard'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d)): ?>
<?php $component = $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d; ?>
<?php unset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-9">
                    <div class="shadow rounded table-responsive bg-white text-dark">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Sl No</th>
                                    <th>Link</th>
                                </tr>
                                <tr>
                                    <td></td>
                                    <td></td>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/work-sheet/completed-worksheet.blade.php ENDPATH**/ ?>