

<?php $__env->startSection('title'); ?>
HDCTC - STUDENT DASHBOARD
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-3 pb-lg-0 pb-md-0 pb-5">
                     <?php if (isset($component)) { $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentDashboard::class, []); ?>
<?php $component->withName('student-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d)): ?>
<?php $component = $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d; ?>
<?php unset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-9 pb-5">
                    <div class="alert bg-green font-weight-bold profile">
                        <?php if($photo): ?>
                            <img src="<?php echo e(asset($photo->photo)); ?>" width="80" alt="">
                        <?php endif; ?>
                       User Id And Password Validity
                    </div>
                    <div class="shadow bg-white rounded table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Payment Date</th>
                                    <?php if($student->payment_date): ?>
                                        <th><?php echo e($student->payment_date); ?></th>
                                    <?php else: ?>
                                        <th>Not Set</th>
                                    <?php endif; ?>
                                </tr>
                                <tr>
                                    <th>Expire Date</th>
                                    <?php if($student->expire_date): ?>
                                        <?php ($date = \Carbon\Carbon::now()->format('Y-m-d')); ?>
                                        <?php ($newDate   =   \Carbon\Carbon::now()->addDays(7)); ?>
                                        <?php if($newDate >= $student->expire_date): ?>
                                        <th><span class="bg-danger text-white p-2"><blink><?php echo e($student->expire_date); ?></blink></span> Please Update User Name & Password</th>
                                        <?php else: ?>
                                        <th><?php echo e($student->expire_date); ?></th>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <th>Not Set</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/dashboard/dashboard.blade.php ENDPATH**/ ?>