

<?php $__env->startSection('title'); ?>
HDCTC - FAQ
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="alert alert-light c-blue font-weight-bold">
                Faq
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrap bg-white p-3">
                        <span class="text-justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit iure ratione quam? Quod, quo architecto repellendus porro, sed eaque, quos iusto ipsa necessitatibus sint provident ullam neque enim. Officia nisi, nesciunt quos facilis ea quaerat, nostrum magnam vero repudiandae est perspiciatis fugit id illo ex, porro ratione sit exercitationem impedit!</span>
                    </div>
                    <div class="wrap bg-white p-3 mt-5">
                        <span class="text-justify">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Sit iure ratione quam? Quod, quo architecto repellendus porro, sed eaque, quos iusto ipsa necessitatibus sint provident ullam neque enim. Officia nisi, nesciunt quos facilis ea quaerat, nostrum magnam vero repudiandae est perspiciatis fugit id illo ex, porro ratione sit exercitationem impedit!</span>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-3"></div>
                <div class="col-lg-6 text-center">
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/faq/faq.blade.php ENDPATH**/ ?>