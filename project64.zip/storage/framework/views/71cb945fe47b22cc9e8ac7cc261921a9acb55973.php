<section class="container" id="socialLink">
    <div class="social-link position-fixed">
        <ul class="">
            <li class="list-unstyled"><a href="" class="d-block border border-dark"><i class="fab fa-facebook"></i></a></li>
            <li class="list-unstyled"><a href="" class="d-block border border-dark"><i class="fab fa-twitter"></i></a></li>
            <li class="list-unstyled"><a href="" class="d-block border border-dark"><i class="fab fa-instagram"></i></a></li>
            <li class="list-unstyled"><a href="" class="d-block border border-dark"><i class="fab fa-youtube"></i></a></li>
            <li class="list-unstyled"><a href="" class="d-block border border-dark"><i class="fab fa-linkedin"></i></a></li>
        </ul>
    </div>
</section><?php /**PATH E:\Laravel-Project\blog\resources\views/components/social-link.blade.php ENDPATH**/ ?>