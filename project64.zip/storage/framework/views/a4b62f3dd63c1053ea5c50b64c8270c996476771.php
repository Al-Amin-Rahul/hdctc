<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Blog - Rahul</title>

        <link href="<?php echo e(asset("/")); ?>front/css/bootstrap.css" rel="stylesheet">
        <link href="<?php echo e(asset("/")); ?>fontawesome/css/all.min.css" rel="stylesheet">
        <link href="<?php echo e(asset("/")); ?>front/css/style.css" rel="stylesheet">
    </head>
    <body>
         <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('header'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php echo $__env->yieldContent('body'); ?>
         <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withName('footer'); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
    </body>
    <script src="<?php echo e(asset("/")); ?>front/js/jquery.min.js"></script>
    <!-- <script>
        var btn = $('#socialLink');

        $(window).scroll(function() {
        if ($(window).scrollTop() > 800) {
            btn.addClass('d-none');
        } else {
            btn.removeClass('d-none');
        }
        });
</script> -->
</html>
<?php /**PATH E:\Laravel-Project\blog\resources\views/front/master.blade.php ENDPATH**/ ?>