

<?php $__env->startSection('body'); ?>
<div class="container">
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Manage Application</li>
</ol>
<?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4" id="showApp">
    <div class="col-lg-6 py-3">
      
      <form action="" method="post">
        <?php echo csrf_field(); ?>
        <select name="job" id="" class="form-control">
          <option selected="true" disabled>Select Job</option>
          <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($job->id); ?>"><?php echo e($job->short_name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        <input type="submit" value="Submit" class="btn btn-success btn-block">
      </form>
    </div>
    
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/job/manage-application.blade.php ENDPATH**/ ?>