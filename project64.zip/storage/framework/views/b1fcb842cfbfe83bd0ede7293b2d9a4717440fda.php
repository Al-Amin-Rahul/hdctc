<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    body{
        font-family: 'Open Sans', sans-serif;
    }
    .top{
        width: 100%;
    }
    .img{
        width: 15%;
        float: left;
        border: 1px solid black;
    }
    .head{
        width: 85%;
        float: left;
        border: 1px solid black;
        background-color: #2ECC71;
    }
    .sec3{
        width: 100%;
    }
    .sec3 .ref{
        width: 50%;
        float: left;
        background-color: grey;
    }
    .sec3 .date{
        width: 50%;
        float: left;
        text-align: right;
        background-color: grey;
    }
</style>
<body>
    <section>
        <div class="top">
            <div class="img">
                <img style="width: 100%" src="https://cdn.pixabay.com/photo/2017/02/19/23/09/success-2081168_1280.jpg" alt="">
            </div>
            <div class="head">
                <h3 style="font-weight: 500;text-align: center">HUMAN DEVELOPMENT COMMUNITY TO COMMUNICATION</h3>
            </div>
        </div>
    </section>
    <section>
        <div class="app" style="text-align: center">Applicant Form (Applicant's Copy)</div>
    </section>
    <section>
        <div class="sec3">
            <div class="ref">
                Reference Id : 
                <?php if(session()->has("refer_code")): ?>
                    <?php echo e(session("refer_code")); ?>

                <?php endif; ?>
            </div>
            <div class="date">
                <?php if(session()->has("created_at")): ?>     
                    <div style="">Date : <?php echo e(session("created_at")); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </section>
    <section>
        <div class="wrap">
            <table class="" style="width: 100%;margin-top: 20px">
                <tbody>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td rowspan="10" style="width: 200px;"></td>
                        <td>Name Of The Post</td>
                        <td>
                            <?php if(session()->has("job_name")): ?>
                                <?php echo e(session("job_name")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Applicant's Name</td>
                        <td>
                            <?php if(session()->has("applicants_name")): ?>
                                <?php echo e(session("applicants_name")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Father's Name</td>
                        <td>
                            <?php if(session()->has("fathers_name")): ?>
                                <?php echo e(session("fathers_name")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Mother's Name</td>
                        <td>
                            <?php if(session()->has("mothers_name")): ?>
                                <?php echo e(session("mothers_name")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Date Of Birth</td>
                        <td>
                            <?php if(session()->has("dob")): ?>
                                <?php echo e(session("dob")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Gender</td>
                        <td>
                            <?php if(session()->has("gender")): ?>
                                <?php echo e(session("gender")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Religion</td>
                        <td>
                            <?php if(session()->has("religion")): ?>
                                <?php echo e(session("religion")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Maritial Status</td>
                        <td>
                            <?php if(session()->has("maritial_status")): ?>
                                <?php echo e(session("maritial_status")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Contact Mobile</td>
                        <td>
                            <?php if(session()->has("phone")): ?>
                                <?php echo e(session("phone")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr style="background-color: rgb(185, 184, 184)">
                        <td>Email</td>
                        <td>
                            <?php if(session()->has("email")): ?>
                                <?php echo e(session("email")); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </section>
    <section>
        <div class="wrap">
            <div class="h6">Address Information :</div>
                <table class="" style="width: 100%">
                    <tbody>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <th colspan="2">Mailing/Present/Address</th>
                            <th colspan="2">Permanent Address</th>
                        </tr>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>Care Of</td>
                            <td>
                                <?php if(session()->has("care_of")): ?>
                                    <?php echo e(session("care_of")); ?>

                                <?php endif; ?>
                            </td>
                            <td>Care Of</td>
                            <td>
                                <?php if(session()->has("care_of_p")): ?>
                                    <?php echo e(session("care_of_p")); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>Village/Town/Road/House/Flat</td>
                            <td>
                                <?php if(session()->has("address")): ?>
                                    <?php echo e(session("address")); ?>

                                <?php endif; ?>
                            </td>
                            <td>Village/Town/Road/House/Flat</td>
                            <td>
                                <?php if(session()->has("address_p")): ?>
                                    <?php echo e(session("address_p")); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>District</td>
                            <td>
                                <?php if(session()->has("district")): ?>
                                    <?php echo e(session("district")); ?>

                                <?php endif; ?>
                            </td>
                            <td>District</td>
                            <td>
                                <?php if(session()->has("district_p")): ?>
                                    <?php echo e(session("district_p")); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>P.S/Upazila</td>
                            <td>
                                <?php if(session()->has("thana")): ?>
                                    <?php echo e(session("thana")); ?>

                                <?php endif; ?>
                            </td>
                            <td>P.S/Upazila</td>
                            <td>
                                <?php if(session()->has("thana_p")): ?>
                                    <?php echo e(session("thana_p")); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>Post Code</td>
                            <td>
                                <?php if(session()->has("post_code")): ?>
                                    <?php echo e(session("post_code")); ?>

                                <?php endif; ?>
                            </td>
                            <td>Post Code</td>
                            <td>
                                <?php if(session()->has("post_code_p")): ?>
                                    <?php echo e(session("post_code_p")); ?>

                                <?php endif; ?>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <div class="h6">Academic Qualifications :</div>
                <table class="table-bordered" style="width: 100%">
                    <thead>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <th>Examination</th>
                            <th>Board/Institute</th>
                            <th>Group/Subject/Degree</th>
                            <th>Result</th>
                            <th>Year</th>
                            <th>Roll</th>
                            <th>Duration</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(session()->has("exam")): ?>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>
                                <?php if(session()->has("exam")): ?>
                                    <?php echo e(session("exam")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(session()->has("board")): ?>
                                    <?php echo e(session("board")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(session()->has("group")): ?>
                                    <?php echo e(session("group")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(session()->has("result")): ?>
                                    <?php echo e(session("result")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(session()->has("pass_year")): ?>
                                    <?php echo e(session("pass_year")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if(session()->has("roll")): ?>
                                    <?php echo e(session("roll")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                N/A
                            </td>
                        </tr>
                        <?php endif; ?>
                        <?php if(session()->has("hsc_board")): ?>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>
                                    <?php if(session()->has("hsc_exam")): ?>
                                    <?php echo e(session("hsc_exam")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("hsc_board")): ?>
                                    <?php echo e(session("hsc_board")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("hsc_group")): ?>
                                    <?php echo e(session("hsc_group")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("hsc_result")): ?>
                                    <?php echo e(session("hsc_result")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("hsc_pass_year")): ?>
                                    <?php echo e(session("hsc_pass_year")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("hsc_roll")): ?>
                                    <?php echo e(session("hsc_roll")); ?>

                                <?php endif; ?>
                            </td>
                            <td>N/A</td>
                        </tr>
                        <?php endif; ?>
                        <?php if(session()->has("graduation_exam")): ?>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <td>
                                    <?php if(session()->has("graduation_exam")): ?>
                                    <?php echo e(session("graduation_exam")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("graduation_board")): ?>
                                    <?php echo e(session("graduation_board")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("graduation_group")): ?>
                                    <?php echo e(session("graduation_group")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("graduation_result")): ?>
                                    <?php echo e(session("graduation_result")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("graduation_pass_year")): ?>
                                    <?php echo e(session("graduation_pass_year")); ?>

                                <?php endif; ?>
                            </td>
                            <td>
                                    <?php if(session()->has("graduation_roll")): ?>
                                    <?php echo e(session("graduation_roll")); ?>

                                <?php endif; ?>
                            </td>
                            <td>N/A</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <table class="table-bordered" style="width: 100%;margin-top: 20px">
                    <tbody>
                        <tr style="background-color: rgb(185, 184, 184)">
                            <th>Departmental Candidate Status</th>
                            <th>N/A</th>
                        </tr>
                    </tbody>
                </table>
                <p>I declare that the information provided in this form are correct, true and complete to the best of my knowledge and belief. If any information is found false, incorrect, and incomplete or if any detected before or after examination, any action can be taken against me by the Authority including cancellation of my candidature.</p>
                <p>Reference Id : <?php if(session()->has('refer_code')): ?>
                    <?php echo e(session('refer_code')); ?>

                <?php endif; ?>, Please keep this number to pay the application fee within 72 hours from any mobile phone by Bkash</p><br>
                <p>1st - Format : Dial *247# Or Go to your Bkash App ( Send Money ) ( Mobile Number ) ( Reference ID Code ) ( Pin Number ) send. [Example : ( send money ) ( 01939-244834 ) ( G97999 ) ( 50 ) ( 12344 ) send.] </p>
            </div>
        </div>
    </section>
</body>
</html><?php /**PATH E:\Laravel-Project\project64\resources\views/front/career/download.blade.php ENDPATH**/ ?>