<section class="bg-white pt-2">
    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="header-logo">
                    <a class="text-decoration-none" href="/">
                        <img src="<?php echo e(asset("/")); ?>front/images/weblogo.png"  class="img-fluid shadow-sm" alt=""/>
                    </a>
                </div>
            </div>
            <div class="col-lg-6">
                <form action="" class="search-form py-lg-4 pl-lg-5">
                    <div class="input-group">
                        <input type="search" name="search" class="form-control border-dark text-danger" id="" placeholder="Search Post">
                        <div class="input-group-append">
                            <input type="submit" value="Search" class="form-control btn btn-dark">
                        </div>
                    </div>                    
                </form>
            </div>
            <div class="col-lg-3">
                <ul class="nav py-4 justify-content-end">
                    <li class="nav-link"><a href=""><i class="fab fa-facebook c-pink"></i></a></li>
                    <li class="nav-link"><a href=""><i class="fab fa-twitter c-pink"></i></a></li>
                    <li class="nav-link"><a href=""><i class="fab fa-linkedin c-pink"></i></a></li>
                    <li class="nav-link"><a href=""><i class="fab fa-instagram c-pink"></i></a></li>
                    <li class="nav-link pr-0"><a href=""><i class="fab fa-google-plus c-pink"></i></a></li>
                </ul>
            </div>
        </div>
    </div>
</section>
<section class="sticky-top bg-dark shadow-sm">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="menu">
                    <ul class="nav justify-content-end">
                        <li class="nav-link bg-pink"><a href="" class="text-white">Home</a></li>
                        <li class="nav-link"><a href="" class="text-white">Electronics</a></li>
                        <li class="nav-link"><a href="" class="text-white">Science</a></li>
                        <li class="nav-link"><a href="" class="text-white">International</a></li>
                        <li class="nav-link"><a href="" class="text-white">Animals</a></li>
                        <li class="nav-link"><a href="" class="text-white">Sports</a></li>
                        <li class="nav-link pr-0"><a href="" class="text-white">Others</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH E:\Laravel-Project\blog\resources\views/components/header.blade.php ENDPATH**/ ?>