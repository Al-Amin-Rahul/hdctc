

<?php $__env->startSection('title'); ?>
    HDCTC - Applicants Copy
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section style="background-color: white">
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-12">
                    <table class="table table-bordered">
                        <tbody>
                            <tr>
                                <td>
                                    <img src="<?php echo e(asset('front/images/logo2.jpg')); ?>" class="" width="115px" alt="">
                                </td>
                                <td colspan="" class="bg-green text-center align-middle">
                                    <h2 class="font-weight-bold">HUMAN DEVELOPMENT COMMUNITY TO COMMUNICATION</h2>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="col-lg-12 text-center">
                        <div class="h4 font-weight-bold">Applicant Form (Applicant's Copy)</div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="bg-gray">Reference Id : 
                        <?php if(session()->has("refer_code")): ?>
                            <?php echo e(session("refer_code")); ?>

                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6 text-right">
                    <?php if(session()->has("created_at")): ?>     
                        <div class="bg-gray">Date : <?php echo e(session("created_at")); ?></div>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row" style="margin-top: 10px">
                <div class="col-lg-12">
                    <table class="table-bordered" style="width: 100%">
                        <tbody>
                            <tr>
                                <td rowspan="10" style="width: 200px;">
                                    <?php if(session()->has("photo")): ?>
                                        <img src="<?php echo e(session("photo")); ?>" class="img-fluid" alt="">
                                    <?php endif; ?>
                                </td>
                                <td style="background-color: rgb(185, 184, 184)">Name Of The Post</td>
                                <td style="background-color: rgb(185, 184, 184)">
                                    <?php if(session()->has("job_name")): ?>
                                        <?php echo e(session("job_name")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Applicant's Name</td>
                                <td>
                                    <?php if(session()->has("applicants_name")): ?>
                                        <?php echo e(session("applicants_name")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Father's Name</td>
                                <td>
                                    <?php if(session()->has("fathers_name")): ?>
                                        <?php echo e(session("fathers_name")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Mother's Name</td>
                                <td>
                                    <?php if(session()->has("mothers_name")): ?>
                                        <?php echo e(session("mothers_name")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Date Of Birth</td>
                                <td>
                                    <?php if(session()->has("dob")): ?>
                                        <?php echo e(session("dob")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Gender</td>
                                <td>
                                    <?php if(session()->has("gender")): ?>
                                        <?php echo e(session("gender")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Religion</td>
                                <td>
                                    <?php if(session()->has("religion")): ?>
                                        <?php echo e(session("religion")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Maritial Status</td>
                                <td>
                                    <?php if(session()->has("maritial_status")): ?>
                                        <?php echo e(session("maritial_status")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Contact Mobile</td>
                                <td>
                                    <?php if(session()->has("phone")): ?>
                                        <?php echo e(session("phone")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Email</td>
                                <td>
                                    <?php if(session()->has("email")): ?>
                                        <?php echo e(session("email")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="h6">Address Information :</div>
                    <table class="table-bordered" style="width: 100%">
                        <tbody>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <th colspan="2">Mailing/Present/Address</th>
                                <th colspan="2">Permanent Address</th>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Care Of</td>
                                <td>
                                    <?php if(session()->has("care_of")): ?>
                                        <?php echo e(session("care_of")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>Care Of</td>
                                <td>
                                    <?php if(session()->has("care_of_p")): ?>
                                        <?php echo e(session("care_of_p")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Village/Town/Road/House/Flat</td>
                                <td>
                                    <?php if(session()->has("address")): ?>
                                        <?php echo e(session("address")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>Village/Town/Road/House/Flat</td>
                                <td>
                                    <?php if(session()->has("address_p")): ?>
                                        <?php echo e(session("address_p")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>District</td>
                                <td>
                                    <?php if(session()->has("district")): ?>
                                        <?php echo e(session("district")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>District</td>
                                <td>
                                    <?php if(session()->has("district_p")): ?>
                                        <?php echo e(session("district_p")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>P.S/Upazila</td>
                                <td>
                                    <?php if(session()->has("thana")): ?>
                                        <?php echo e(session("thana")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>P.S/Upazila</td>
                                <td>
                                    <?php if(session()->has("thana_p")): ?>
                                        <?php echo e(session("thana_p")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>Post Code</td>
                                <td>
                                    <?php if(session()->has("post_code")): ?>
                                        <?php echo e(session("post_code")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>Post Code</td>
                                <td>
                                    <?php if(session()->has("post_code_p")): ?>
                                        <?php echo e(session("post_code_p")); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <div class="h6">Academic Qualifications :</div>
                    <table class="table-bordered" style="width: 100%">
                        <thead>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <th>Examination</th>
                                <th>Board/Institute</th>
                                <th>Group/Subject/Degree</th>
                                <th>Result</th>
                                <th>Year</th>
                                <th>Roll</th>
                                <th>Duration</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if(session()->has("exam")): ?>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>
                                    <?php if(session()->has("exam")): ?>
                                        <?php echo e(session("exam")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(session()->has("board")): ?>
                                        <?php echo e(session("board")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(session()->has("group")): ?>
                                        <?php echo e(session("group")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(session()->has("result")): ?>
                                        <?php echo e(session("result")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(session()->has("pass_year")): ?>
                                        <?php echo e(session("pass_year")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if(session()->has("roll")): ?>
                                        <?php echo e(session("roll")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    N/A
                                </td>
                            </tr>
                            <?php endif; ?>
                            <?php if(session()->has("hsc_board")): ?>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>
                                     <?php if(session()->has("hsc_exam")): ?>
                                        <?php echo e(session("hsc_exam")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("hsc_board")): ?>
                                        <?php echo e(session("hsc_board")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("hsc_group")): ?>
                                        <?php echo e(session("hsc_group")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("hsc_result")): ?>
                                        <?php echo e(session("hsc_result")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("hsc_pass_year")): ?>
                                        <?php echo e(session("hsc_pass_year")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("hsc_roll")): ?>
                                        <?php echo e(session("hsc_roll")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>N/A</td>
                            </tr>
                            <?php endif; ?>
                            <?php if(session()->has("graduation_exam")): ?>
                            <tr style="background-color: rgb(185, 184, 184)">
                                <td>
                                     <?php if(session()->has("graduation_exam")): ?>
                                        <?php echo e(session("graduation_exam")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("graduation_board")): ?>
                                        <?php echo e(session("graduation_board")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("graduation_group")): ?>
                                        <?php echo e(session("graduation_group")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("graduation_result")): ?>
                                        <?php echo e(session("graduation_result")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("graduation_pass_year")): ?>
                                        <?php echo e(session("graduation_pass_year")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                     <?php if(session()->has("graduation_roll")): ?>
                                        <?php echo e(session("graduation_roll")); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    N/A
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <p>I declare that the information provided in this form are correct, true and complete to the best of my knowledge and belief. If any information is found false, incorrect, and incomplete or if any detected before or after examination, any action can be taken against me by the Authority including cancellation of my candidature.</p>
                    <h6 style="font-weight: 600; margin-top: 30px">Congratulations!! Application Submitted Successfully</h6>
                    <p>Reference Id : <?php if(session()->has('refer_code')): ?>
                    <?php echo e(session('refer_code')); ?>

                <?php endif; ?>, Please keep this number to pay the application fee within 72 from any mobile phone by Bkash</p><br>
                    <p>1st - Format : Dial *247# Or Go to your Bkash App < Send Money > < Mobile Number > < Reference ID Code > < Pin Number > send. [Example : < send money > < 01939-244834 > < G97999 > < 50 > < 12344 > send.] </p>
                </div>
            </div>
        </div>
    </section>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-12 text-center">
                    <a href="<?php echo e(route('download-application-form')); ?>" class="btn btn-danger">Download Copy <i class="fas fa-download"></i></a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/career/applicants-copy.blade.php ENDPATH**/ ?>