

<?php $__env->startSection('body'); ?>
    <div class="container">
        <!-- Breadcrumbs-->
        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">Edit Student</li>
        </ol>
        <div class="row">
            <div class="col-md-12">
                <div class="row col-md-6 offset-md-2">
                    <h2></h2>
                </div>
                <?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route("admin.student.update", ['student' => $student->id])); ?>" method="post" class="shadow p-5 rounded" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field("PUT"); ?>
                    <div class="form-group row">
                        <label for="studentName" class="col-lg-3">Student Name</label>
                        <div class="col-lg-9">
                            <input type="text" name="student_name" value="<?php echo e($student->student_name); ?>" class="form-control" id="studentName">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="control-label col-sm-4" for="">Image</label>
                        <img src="<?php echo e(asset($student->image)); ?>" width="80" alt="">
                        <input type="file" name="image" class="form-control col-sm-6" id="">
                    </div>
                    <div class="form-group row">
                        <label for="service" class="col-lg-3">Service</label>
                        <div class="col-lg-9">
                            <input type="text" name="service" value="<?php echo e($student->service); ?>" class="form-control" id="refer">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="service_option" class="col-lg-3">Service Option</label>
                        <div class="col-lg-9">
                            <input type="text" name="service_option" value="<?php echo e($student->service_option); ?>" class="form-control" id="refer">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="nid" class="col-lg-3">Nid</label>
                        <div class="col-lg-9">
                            <input type="text" name="nid" value="<?php echo e($student->nid); ?>" class="form-control" id="refer">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="mobile_banking" class="col-lg-3">Mobile Banking</label>
                        <div class="col-lg-9">
                            <input type="text" name="mobile_banking" value="<?php echo e($student->mobile_banking); ?>" class="form-control" id="refer">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="refer" class="col-lg-3">Refer Code</label>
                        <div class="col-lg-9">
                            <input type="text" name="refer_code" value="<?php echo e($student->refer_code); ?>" class="form-control" id="refer">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="dob" class="col-lg-3">Date Of Birth</label>
                        <div class="col-lg-9">
                            <input type="date" name="dob" value="<?php echo e($student->dob); ?>" class="form-control" id="dob">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="gender" class="col-lg-3">Gender</label>
                        <div class="col-lg-9">
                            <input type="radio" value="1" name="gender" id="gender" <?php echo e($student->gender == 1 ? 'checked':''); ?>>Male
                            <input type="radio" value="2" name="gender" id="gender" <?php echo e($student->gender == 2 ? 'checked':''); ?>>Female
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="studentEmail" class="col-lg-3">Email</label>
                        <div class="col-lg-9">
                            <input type="email" name="student_email" value="<?php echo e($student->student_email); ?>" class="form-control" id="studentEmail">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="studentPhone" class="col-lg-3">Phone</label>
                        <div class="col-lg-9">
                            <input type="number" name="student_phone" value="<?php echo e($student->student_phone); ?>" class="form-control" id="studentPhone">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="educationQ" class="col-lg-3">Education Qualification</label>
                        <div class="col-lg-9">
                            <input type="radio" value="1" name="education" id="educationQ" <?php echo e($student->education == 1 ? 'checked':''); ?>>SSC
                            <input type="radio" value="2" name="education" id="educationQ" <?php echo e($student->education == 2 ? 'checked':''); ?>>HSC
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="fatherName" class="col-lg-3">Father Name</label>
                        <div class="col-lg-9">
                            <input type="text" name="father_name" value="<?php echo e($student->father_name); ?>" class="form-control" id="fatherName">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="motherName" class="col-lg-3">Mother Name</label>
                        <div class="col-lg-9">
                            <input type="text" name="mother_name" value="<?php echo e($student->mother_name); ?>" class="form-control" id="motherName">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="selectDiv" class="col-lg-3">Division</label>
                        <div class="col-lg-9">
                            <select name="division" id="selectDiv" class="form-control">
                                <option selected="true" disabled="disabled">Select Division</option>
                                <?php $__currentLoopData = $divisions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $division): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($division->id); ?>" <?php echo e($s_div   ==  $division->id ? 'selected':''); ?>><?php echo e($division->div_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="district" class="col-lg-3">District</label>
                        <div class="col-lg-9">
                            <select name="district" id="district" class="form-control">
                                <option selected="true" disabled="disabled">Select District</option>
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($district->id); ?>" <?php echo e($s_dis   ==  $district->id ? 'selected':''); ?>><?php echo e($district->dis_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="thana" class="col-lg-3">Thana</label>
                        <div class="col-lg-9">
                            <select name="thana" id="thana" class="form-control">
                                <option selected="true" disabled="disabled">Select Thana</option>
                                <?php $__currentLoopData = $thanas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thana): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($thana->id); ?>" <?php echo e($s_thana   ==  $thana->id ? 'selected':''); ?>><?php echo e($thana->thana_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="union" class="col-lg-3">Union</label>
                        <div class="col-lg-9">
                            <select name="union" id="union" class="form-control">
                                <option selected="true" disabled="disabled">Select Union</option>
                                <?php $__currentLoopData = $unions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $union): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($union->id); ?>" <?php echo e($s_union   ==  $union->id ? 'selected':''); ?>><?php echo e($union->union_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="post" class="col-lg-3">Post Code</label>
                        <div class="col-lg-9">
                            <input type="number" name="post_code" value="<?php echo e($student->post_code); ?>" class="form-control" id="post">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="payment_date" class="col-lg-3">Payement Date</label>
                        <div class="col-lg-9">
                            <input type="date" name="payment_date" value="<?php echo e($student->payment_date); ?>" class="form-control" id="post">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="expire_date" class="col-lg-3">Payement Date</label>
                        <div class="col-lg-9">
                            <input type="date" name="expire_date" value="<?php echo e($student->expire_date); ?>" class="form-control" id="post">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="status" class="col-lg-3">Status</label>
                        <div class="col-lg-9">
                            <select name="status" id="" class="form-control">
                                <option value="<?php echo e($student->status); ?>" <?php echo e($student->status == "Pending" ? 'selected':''); ?>><?php echo e($student->status); ?></option>
                                <option value="Success">Success</option>
                                <option value="pending">Pending</option>
                            </select>
                        </div>
                    </div>
                    <input type="submit" value="Update" name="submit" class="btn btn-primary form-control">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/student/edit-student.blade.php ENDPATH**/ ?>