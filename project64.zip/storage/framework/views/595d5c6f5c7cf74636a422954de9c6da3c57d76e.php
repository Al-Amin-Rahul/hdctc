

<?php $__env->startSection('body'); ?>
<div class="container">
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Manage Success Application</li>
</ol>
<?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4" id="showApp">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead class="bg-primary text-white">
            <tr>
              <th>No</th>
              <th>Image</th>
              <th>Job Name</th>
              <th>Refer Code</th>
              <th>Name</th>
              <th>Father Name</th>
              <th>Mother Name</th>
              <th>NID</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Image</th>
              <th>Job Name</th>
              <th>Refer Code</th>
              <th>Name</th>
              <th>Father Name</th>
              <th>Mother Name</th>
              <th>NID</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php ($i = 1); ?>
          <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><img src="<?php echo e(asset($app->image)); ?>" width="80" alt=""></td>
              <td><?php echo e($app->job_id); ?></td>
              <td><?php echo e($app->refer_code); ?></td>
              <td><?php echo e($app->applicants_name); ?></td>
              <td><?php echo e($app->fathers_name); ?></td>
              <td><?php echo e($app->mothers_name); ?></td>
              <td><?php echo e($app->nid); ?></td>
              <td><?php echo e($app->phone); ?></td>
              <td><?php echo e($app->email); ?></td>
              <td>
                <a href="<?php echo e(route("admin.job.show", ["job" => $app->id ])); ?>" class="btn-circle btn-primary"><i class="fas fa-edit"></i></a></br></br>
                <a href="<?php echo e(route("admin.delete-app", ["id" => $app->id ])); ?>" class="btn-circle btn-danger"><i class="fas fa-trash"></i></a></br></br>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/job/manage-success-application.blade.php ENDPATH**/ ?>