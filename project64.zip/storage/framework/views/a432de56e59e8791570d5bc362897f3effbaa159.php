

<?php $__env->startSection('title'); ?>
    HOME - Submit Info
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-3 pb-lg-0 pb-md-0 pb-5">
                     <?php if (isset($component)) { $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentDashboard::class, []); ?>
<?php $component->withName('student-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d)): ?>
<?php $component = $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d; ?>
<?php unset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-9">
                    <?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <form action="<?php echo e(route("submit-student-info")); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="shadow rounded bg-white p-5">
                            <div class="form-group row">
                                <label for="link" class="col-lg-3">Link</label>
                                <div class="col-lg-9">
                                    <input type="text" name="link" class="form-control" id="link">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="wTime" class="col-lg-3">Watch Time</label>
                                <div class="col-lg-9">
                                    <input type="text" name="watch_time" class="form-control" id="wTime">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="tSub" class="col-lg-3">Total Sub</label>
                                <div class="col-lg-9">
                                    <input type="text" name="total_sub" class="form-control" id="tSub">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="tView" class="col-lg-3">Total View</label>
                                <div class="col-lg-9">
                                    <input type="text" name="total_view" class="form-control" id="tView">
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" value="Submit" class="form-control btn btn-primary">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/submit-info/submit-information.blade.php ENDPATH**/ ?>