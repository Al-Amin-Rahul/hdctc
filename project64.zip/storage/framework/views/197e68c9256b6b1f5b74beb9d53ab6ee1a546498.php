

<?php $__env->startSection('title'); ?>
    HOME - PROFILE
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-3 pb-lg-0 pb-md-0 pb-5">
                     <?php if (isset($component)) { $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\StudentDashboard::class, []); ?>
<?php $component->withName('student-dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d)): ?>
<?php $component = $__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d; ?>
<?php unset($__componentOriginal18d13e588a1f0148370acc8bff235a0d5f7fa33d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
                </div>
                <div class="col-lg-9">
                    <div class="shadow rounded bg-white text-dark p-5">
                        <form action="<?php echo e(route("update-student")); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
                            <div class="form-group row">
                                <label for="name" class="col-lg-3">Name</label>
                                <div class="col-lg-9">
                                    <input type="text" class="form-control" name="name" value="<?php echo e($student->name); ?>" id="name">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="email" class="col-lg-3">Email</label>
                                <div class="col-lg-9">
                                    <input type="email" class="form-control" name="email" value="<?php echo e($student->email); ?>" id="email">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="channel" class="col-lg-3">Channel Name</label>
                                <div class="col-lg-9">
                                    <input type="text" class="form-control" name="channel" value="<?php echo e($student->channel); ?>" id="channel">
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="photo" class="col-lg-3">Upload Photo</label>
                                <div class="col-lg-2"><img src="<?php echo e(asset($student->photo)); ?>" width="100"alt=""></div>
                                <div class="col-lg-7">
                                    <input type="file" class="form-control" name="image" id="photo">
                                </div>
                            </div>
                            <input type="submit" value="Update Profile" class="btn btn-primary form-control">
                        </form>
                        <div class="text-center pt-5">
                            <a href="<?php echo e(route("change-password")); ?>"><u>Change Password</u></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/profile/student-profile.blade.php ENDPATH**/ ?>