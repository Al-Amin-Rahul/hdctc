

<?php $__env->startSection('body'); ?>
<div class="container">
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Manage student Success</li>
</ol>
<?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead class="bg-primary text-white">
            <tr>
              <th>No</th>
              <th>Image</th>
              <th>Student Name</th>
              <th>Refer Code</th>
              <th>DOB</th>
              <th>Gender</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Education</th>
              <th>Father</th>
              <th>Mother</th>
              <th>Division</th>
              <th>District</th>
              <th>Thana</th>
              <th>Union</th>
              <th>Post Code</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Image</th>
              <th>Student Name</th>
              <th>Refer Code</th>
              <th>DOB</th>
              <th>Gender</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Education</th>
              <th>Father</th>
              <th>Mother</th>
              <th>Division</th>
              <th>District</th>
              <th>Thana</th>
              <th>Union</th>
              <th>Post Code</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php ($i = 1); ?>
          <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><img src="<?php echo e(asset($student->image)); ?>" width="80" alt=""></td>
              <td><?php echo e($student->	student_name); ?></td>
              <td><?php echo e($student->refer_code); ?></td>
              <td><?php echo e($student->dob); ?></td>
              <td><?php echo e($student->gender); ?></td>
              <td><?php echo e($student->student_email); ?></td>
              <td><?php echo e($student->student_phone); ?></td>
              <td><?php echo e($student->education); ?></td>
              <td><?php echo e($student->father_name); ?></td>
              <td><?php echo e($student->mother_name); ?></td>
              <td><?php echo e($student->division); ?></td>
              <td><?php echo e($student->district); ?></td>
              <td><?php echo e($student->thana); ?></td>
              <td><?php echo e($student->union); ?></td>
              <td><?php echo e($student->post_code); ?></td>
              <td>
                <form action="<?php echo e(route("admin.update-student-status")); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <input type="hidden" name="id" value="<?php echo e($student->id); ?>">
                    <select name="status" id="">
                      <option value="<?php echo e($student->status); ?>"><?php echo e($student->status); ?></option>
                      <option value="Success">Success</option>
                      <option value="pending">Pending</option>
                  </select>
                  <hr>
                  <input class="btn btn-primary btn-sm btn-block" type="submit" name="update" value="Update" >
                </form>
              </td>
              <td>
                  <a href="<?php echo e(route("admin.student.edit", ["student" => $student->id ])); ?>" class="btn-circle btn-primary"><i class="fas fa-edit"></i></a></br></br>
                  <form action="<?php echo e(route("admin.student.destroy",['student' => $student->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field("DELETE"); ?>
                      <button class="btn-circle btn-danger" type="submit" onclick="return confirm('Are your sure')"><span class="fa fa-trash"></span></button>
                  </form><br>
                  <a href="<?php echo e(route("admin.download", ["id" => $student->id ])); ?>" class="btn-circle btn-warning"><i class="fas fa-download"></i></a>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/student/manage-success-student.blade.php ENDPATH**/ ?>