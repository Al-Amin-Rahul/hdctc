<section class="bg-pink pt-4">
    <div class="container">
        <div class="row">
            <div class="col-lg-2">
                <ul class="pl-0">
                    <li class="nav-link pl-0 font-weight-bold text-dark">HALAL GHOR</li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Halal Food</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Halal Perfume</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Islamic Book</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Women's Fashion</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Grocery</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Islamic Product</a></li
                </ul>
            </div>
            <div class="col-lg-2">
                <ul class="pl-0">
                    <li class="nav-link pl-0 font-weight-bold text-dark">BLOG</li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Food</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Quran</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Bukhari</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Perfume</a></li>
                </ul>
            </div>
            <div class="col-lg-2">
                <ul class="pl-0">
                    <li class="nav-link pl-0 font-weight-bold text-dark">INFORMATION</li>
                    <li class="nav-link pl-0"><a href="" class="text-white">About Us</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Contact Us</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Facebook</a></li>
                    <li class="nav-link pl-0"><a href="" class="text-white">Youtube</a></li>
                </ul>
            </div>
            <div class="col-lg-6">
                <div class="logo text-right">
                <img class="w-75 img-thumbnail" src="<?php echo e(asset("/")); ?>front/images/weblogo.png" alt="logo"/>
                </div>
                <div class="newslater">
                    <form action="" class="py-3">
                        <div class="input-group">
                            <input type="email" name="email" id="" class="form-control border-dark" placeholder="Enter Your Email To Subscribe Our Newslater">
                            <div class="input-group-append">
                                <input type="submit" value="Subscribe" class="form-control btn btn-dark">
                            </div>
                        </div>
                    </form>
                </div>
                <div class="social border-bottom border-dark">
                    <ul class="nav justify-content-end">
                        <li class="nav-link"><a href=""><i class="fab fa-facebook text-dark"></i></a></li>
                        <li class="nav-link"><a href=""><i class="fab fa-twitter text-dark"></i></a></li>
                        <li class="nav-link"><a href=""><i class="fab fa-linkedin text-dark"></i></a></li>
                        <li class="nav-link"><a href=""><i class="fab fa-instagram text-dark"></i></a></li>
                        <li class="nav-link pr-0"><a href=""><i class="fab fa-google-plus text-dark"></i></a></li>
                    </ul>
                </div>
                <div class="copyright text-right py-1 border-top border-dark">
                    <span>Copyright © 2020, <span class="text-white font-weight-bold">www.blog.halalghor.com</span> All rights reserved</span>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH E:\Laravel-Project\blog\resources\views/components/footer.blade.php ENDPATH**/ ?>