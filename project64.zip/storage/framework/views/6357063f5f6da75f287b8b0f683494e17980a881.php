

<?php $__env->startSection('title'); ?>
HDCTC - LOGIN
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="row">
                <div class="col-lg-4"></div>
                <div class="col-lg-4">
                    <div class="wrap shadow rounded bg-white p-3">
                        <form action="<?php echo e(route("submit-login")); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="title text-center font-weight-bold display-4 c-pink">Login</div>
                            <div class="form-group pt-3">
                                <label for="name">Email</label>
                                <input type="email" class="form-control" name="email" id="name">
                            </div>
                            <div class="form-group">
                                <label for="password">Password</label>
                                <input type="password" class="form-control" name="password" id="password">
                            </div>
                            <div class="form-group">
                                <input type="submit" value="Login" class="form-control btn btn-outline-primary">
                            </div>
                            <small><span>Don't Have An Account <a href="<?php echo e(route("user-signup")); ?>">SignUp</a></span></small>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/login/show-login.blade.php ENDPATH**/ ?>