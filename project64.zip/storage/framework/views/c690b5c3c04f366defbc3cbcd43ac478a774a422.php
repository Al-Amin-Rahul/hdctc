

<?php $__env->startSection('body'); ?>
<div class="container">
<!-- Breadcrumbs-->
<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <a href="#">Dashboard</a>
    </li>
    <li class="breadcrumb-item active">Manage Slider</li>
</ol>
<?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <div class="row">
            <div class="col-lg-6">
                <h6 class="m-0 font-weight-bold text-primary">Manage Slider</h6>
            </div>
        </div>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead class="bg-primary text-white">
            <tr>
              <th>No</th>
              <th>Slider Title</th>
              <th>Short Description</th>
              <th>Image</th>
              <th>Active</th>
              <th>Publication Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Slider Title</th>
              <th>Short Description</th>
              <th>Image</th>
              <th>Active</th>
              <th>Publication Status</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php ($i=1); ?>
          <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><?php echo e($slider->title); ?></td>
              <td><?php echo e($slider->short_description); ?></td>
              <td><img src="<?php echo e(asset($slider->slider_image)); ?>" height="100"/></td>
              <td><?php echo e($slider->active); ?></td>
              <td><?php echo e($slider->publication_status); ?></td>
              <td>
                  <a href="<?php echo e(route("admin.slider.edit", ['slider' =>  $slider->id])); ?>" class="btn-circle btn-primary"><i class="fas fa-edit"></i></a></br></br>
                  <form action="<?php echo e(route("admin.slider.destroy", ['slider' =>  $slider->id])); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field("DELETE"); ?>
                      <button class="btn-circle btn-danger" type="submit" onclick="return confirm('Are your sure')"><span class="fa fa-trash"></span></button>
                  </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/slider/manage-slider.blade.php ENDPATH**/ ?>