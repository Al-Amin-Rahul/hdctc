

<?php $__env->startSection('title'); ?>
HDCTC - COURSE DETAILS
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="alert alert-light c-blue font-weight-bold">
                Course Details
            </div>
            <div class="row">
                <div class="col-lg-6">
                    <div class="image">
                        <?php if($course): ?>
                        <img src="<?php echo e(asset($course->image)); ?>"  class="img-fluid w-100" alt=""/>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-lg-6">
                    <?php if($course): ?>
                        <div class="wrap bg-white p-5">
                            <?php echo $course->course_feature; ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/course-details/course-details.blade.php ENDPATH**/ ?>