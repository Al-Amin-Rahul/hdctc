<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="theme-color" content="#89C74A">
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="msnbot" content="index,follow" />
        <meta name="robots" content="index,follow" />
        <meta name="googlebot" content="all" />
        <meta property="fb:app_id" content="345891736236545" />
        <?php echo $__env->yieldContent('meta'); ?>
        <link rel="icon" href="<?php echo e(asset("/")); ?>front/images/tab.png" type="image/gif" sizes="32x32">
        <link href="<?php echo e(asset("/")); ?>front/css/bootstrap.css" rel="stylesheet">
        <link href="<?php echo e(asset("/")); ?>fontawesome/css/all.min.css" rel="stylesheet">
        <link href="<?php echo e(asset("/")); ?>front/css/jquery.lighter.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset("/")); ?>front/css/owl.carousel.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset("/")); ?>front/css/style.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
        <link rel="preconnect" href="https://fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300&display=swap" rel="stylesheet">
    </head>
    <body>
        <!-- Load Facebook SDK for JavaScript -->
      <!-- Load Facebook SDK for JavaScript -->
      <div id="fb-root"></div>
      <script>
        window.fbAsyncInit = function() {
          FB.init({
            xfbml            : true,
            version          : 'v9.0'
          });
        };

        (function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
        fjs.parentNode.insertBefore(js, fjs);
      }(document, 'script', 'facebook-jssdk'));</script>

      <!-- Your Chat Plugin code -->
      <div class="fb-customerchat"
        attribution=setup_tool
        page_id="110079830845589"
        theme_color="#67b868">
      </div>
         <?php if (isset($component)) { $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Header::class, []); ?>
<?php $component->withName('header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3)): ?>
<?php $component = $__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3; ?>
<?php unset($__componentOriginal99db13291ff287454d08b974e14dad64f9e2c6f3); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
         <?php if (isset($component)) { $__componentOriginal040d42950c117c319000b3746c3804f91975a438 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\MobileMenu::class, []); ?>
<?php $component->withName('mobile-menu'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal040d42950c117c319000b3746c3804f91975a438)): ?>
<?php $component = $__componentOriginal040d42950c117c319000b3746c3804f91975a438; ?>
<?php unset($__componentOriginal040d42950c117c319000b3746c3804f91975a438); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php echo $__env->yieldContent('body'); ?>
         <?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
    <script src="<?php echo e(asset("/")); ?>front/js/jquery.min.js"></script>
    <script src="<?php echo e(asset("/")); ?>front/js/select.js"></script>
    <script src="<?php echo e(asset("/")); ?>front/js/active.js"></script>
    <script src="<?php echo e(asset("/")); ?>front/js/bootstrap.js"></script>
    <script src="<?php echo e(asset("/")); ?>front/js/jquery.lighter.js"></script>
    <script src="<?php echo e(asset("/")); ?>front/js/owl.carousel.min.js"></script>
    <script>
        var owl = $('.owl-carousel');
        owl.owlCarousel({
            items: 3,
            loop: true,
            margin: 20,
            autoplay: true,
            autoplayTimeout: 3000,
            autoplayHoverPause: true,
            autoHeight: false,
            autoHeightClass: 'owl-height',
            nav: false,
            dots: false,
            responsiveClass: true,

            responsive: {
                0: {
                    items: 1,
                    loop: true
                },
                768: {
                    items: 2,
                    loop: true
                },
                1000: {
                    items: 3,
                    loop: true
                },
            }

        });
    </script>
    <script>
        function openNav() {
        document.getElementById("mySidenav").style.width = "250px";
        }

        function closeNav() {
        document.getElementById("mySidenav").style.width = "0";
        }
        </script>
</html>
<?php /**PATH E:\Laravel-Project\project64\resources\views/front/master.blade.php ENDPATH**/ ?>