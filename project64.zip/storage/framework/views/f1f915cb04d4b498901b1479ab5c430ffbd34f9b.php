

<?php $__env->startSection('title'); ?>
    HDCTC - Job Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <div class="row">
                <div class="col-lg-8">
                    <div class="bg-white p-3">
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="title">
                                    <h2 class="font-weight-bold"><?php echo e($job->short_name); ?></h2>
                                    <h4><?php echo e($job->organization_name); ?></h4>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <img src="<?php echo e(asset($job->image)); ?>" class="img-fluid" alt="">
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <?php echo $job->description; ?>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="summary">
                        <ul class="list-group">
                            <li class="list-group-item active"><span class="font-weight-bold">Job Summary</span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Published On - <?php echo e($job->created_at); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Vacancy - <?php echo e($job->vacancy); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Employment Status - <?php echo e($job->employment_status); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Experience - <?php echo e($job->experience); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Age : <?php echo e($job->age); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Job Location - <?php echo e($job->job_location); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Salary : <?php echo e($job->salary); ?></span></li>
                            <li class="list-group-item"><span class="font-weight-bold">Application Deadline : <?php echo e($job->deadline); ?></span></li>
                            <li class="list-group-item"><a href="<?php echo e(route('apply-online', ['id'=> $job->id])); ?>" class="btn btn-warning d-block font-weight-bold">Apply Now</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/career/job-details.blade.php ENDPATH**/ ?>