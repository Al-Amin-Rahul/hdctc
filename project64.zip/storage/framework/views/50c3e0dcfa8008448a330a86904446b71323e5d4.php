

<?php $__env->startSection('title'); ?>
    HDCTC - MEMBER COPY
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <?php echo $__env->make('message.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="alert alert-light c-blue font-weight-bold">
                Member Copy
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <div class="wrap bg-dark text-white p-5 shadow-sm rounded">
                        <div class="title display-4 font-weight-bold">Member Copy</div>
                        <br>
                        <div class="shadow rounded table-responsive bg-warning text-dark" id="printContent">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>
                                        <?php if(session()->has("name")): ?>
                                            <?php echo e(session("name")); ?>

                                        <?php endif; ?>
                                        </th>
                                    </tr>
                                    <tr>
                                        <th>Refer Code</th>
                                        <th>
                                        <?php if(session()->has("code")): ?>
                                            <?php echo e(session("code")); ?>

                                        <?php endif; ?>
                                        </th>
                                    </tr>
                                </thead>
                            </table>
                        </div>
                        <br>
                        <a href="<?php echo e(route("download-reciept")); ?>" class="btn btn-outline-warning font-weight-bold">Download Copy <i class="fas fa-download"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/reciept/student-copy.blade.php ENDPATH**/ ?>