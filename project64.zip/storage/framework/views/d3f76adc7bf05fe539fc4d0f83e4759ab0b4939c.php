

<?php $__env->startSection('title'); ?>
    HDCTC - Career
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
    <section>
        <div class="container pt-5 pb-5">
            <table class="table table-hover table-bordered">
                <thead>
                    <tr>
                    <th scope="col">Logo</th>
                    <th scope="col">Short Name</th>
                    <th scope="col">Organization Name</th>
                    <th scope="col">WebLink</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><img class="img-fluid" src="<?php echo e(asset($job->image)); ?>" alt="" style="width:100px;"></th>
                        <td><?php echo e($job->short_name); ?></td>
                        <td><?php echo e($job->organization_name); ?></td>
                        <td><a href="<?php echo e(route("job-details", ['id' => $job->id])); ?>" target="_blank">View More Details</a></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Laravel-Project\project64\resources\views/front/career/career.blade.php ENDPATH**/ ?>