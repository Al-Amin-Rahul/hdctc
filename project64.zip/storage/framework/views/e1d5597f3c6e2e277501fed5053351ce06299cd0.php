<div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
          <thead class="bg-primary text-white">
            <tr>
              <th>No</th>
              <th>Image</th>
              <th>Job Name</th>
              <th>Refer Code</th>
              <th>Name</th>
              <th>Father Name</th>
              <th>Mother Name</th>
              <th>NID</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tfoot>
            <tr>
              <th>No</th>
              <th>Image</th>
              <th>Job Name</th>
              <th>Refer Code</th>
              <th>Name</th>
              <th>Father Name</th>
              <th>Mother Name</th>
              <th>NID</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </tfoot>
          <tbody>
          <?php ($i = 1); ?>
          <?php $__currentLoopData = $apps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($i++); ?></td>
              <td><img src="<?php echo e(asset($app->image)); ?>" width="80" alt=""></td>
              <td><?php echo e($app->job_id); ?></td>
              <td><?php echo e($app->refer_code); ?></td>
              <td><?php echo e($app->applicants_name); ?></td>
              <td><?php echo e($app->fathers_name); ?></td>
              <td><?php echo e($app->mothers_name); ?></td>
              <td><?php echo e($app->nid); ?></td>
              <td><?php echo e($app->phone); ?></td>
              <td><?php echo e($app->email); ?></td>
              <td>
                <form action="<?php echo e(route("admin.update-status")); ?>" method="post" id="UpdateStatus">
                    <?php echo csrf_field(); ?>
                        <select name="status" id="">
                        <option value="<?php echo e($app->status); ?>"><?php echo e($app->status); ?></option>
                        <option value="Success">Success</option>
                        <option value="Pending">Pending</option>
                    </select>
                    <hr>
                    <input type="hidden" name="id" value="<?php echo e($app->id); ?>">
                    <input class="btn btn-primary btn-sm btn-block" type="submit" name="update" value="Update" >
                </form>
              </td>
              <td>
                <a href="<?php echo e(route("admin.job.show", ["job" => $app->id ])); ?>" class="btn-circle btn-primary"><i class="fas fa-edit"></i></a></br></br>
                <form action="<?php echo e(route("admin.delete-app")); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input type="hidden" name="id" value="<?php echo e($app->id); ?>">
                      <button class="btn-circle btn-danger" type="submit" onclick="return confirm('Are your sure')"><span class="fa fa-trash"></span></button>
                  </form>
              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div><?php /**PATH E:\Laravel-Project\project64\resources\views/admin/job/show-app.blade.php ENDPATH**/ ?>