<div class="wrap shadow rounded" id="student-menu">
    <ul class="list-group">
        <a href="<?php echo e(route("user-dashboard")); ?>"><li class="list-group-item bg-green border-rds text-center text-white font-weight-bolder">Welcome <?php echo e(Session::get('student_name')); ?></li> <br></a>
        <a class="text-white text-center" href="<?php echo e(route("user-profile")); ?>"><li class="list-group-item bg-dark border-rds">Profile</li></a>
        <a class="text-white text-center" target="_blank" href="<?php echo e(route("manage-student",['id' => session('student_id')])); ?>"><li class="list-group-item bg-dark border-rds">Manage Student</li></a>
        <a class="text-white text-center" href="<?php echo e(route("daily-work-sheet")); ?>"><li class="list-group-item bg-dark border-rds">Daily Work Sheet</li></a>
        <a class="text-white text-center" href="<?php echo e(route("submit-information")); ?>"><li class="list-group-item bg-dark border-rds">Submit Information</li></a>
        <a href="<?php echo e(route("user-logout")); ?>" class="text-white text-center"><li class="list-group-item bg-dark border-rds">Log Out</li></a>
    </ul>
</div><?php /**PATH E:\Laravel-Project\project64\resources\views/components/student-dashboard.blade.php ENDPATH**/ ?>