<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
    <ul class="nav">
        <li class="nav-link"><a href="/" class="text-white"><i class="fas fa-home text-dark"></i> Home</a></li>
        <li class="nav-link"><a href="<?php echo e(route("about-us")); ?>" class="text-white"><i class="fas fa-user text-dark"></i> About</a></li>
        <li class="nav-link"><a href="<?php echo e(route("gallery")); ?>" class="text-white"><i class="fas fa-image text-dark"></i> Gallery</a></li>
        <li class="nav-link"><a href="#" class="text-white"><i class="fas fa-book text-dark"></i> Course <i class="fas fa-angle-down"></i></a>
            <ul class="nav d-none sub-menu bg-dark">
                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-link"><a class="text-white" href="<?php echo e(route("course-details", ['id' => $course->id])); ?>"><i class="fas fa-book text-light"></i> <?php echo e($course->name); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li class="nav-link"><a href="#" class="text-white"><i class="fas fa-link text-dark"></i> Service <i class="fas fa-angle-down"></i></a>
            <ul class="nav d-none sub-menu bg-dark">
                <li class="nav-link"><a class="text-white" href="<?php echo e(route("vata")); ?>"><i class="fas fa-book text-light"></i>ভাতা</a></li>
            </ul>
        </li>
        <li class="nav-link"><a href="<?php echo e(route("career")); ?>" class="text-white"><i class="fas fa-link text-dark"></i> Career</a></li>
        <li class="nav-link"><a href="<?php echo e(route("student-registration")); ?>" class="text-white"><i class="text-dark fas fa-address-card"></i> Registration</a></li>
        <li class="nav-link"><a href="<?php echo e(route("contact-us")); ?>" class="text-white"><i class="fas fa-mobile text-dark"></i> Contact</a></li>
        <?php if(Session::get('student_id')): ?>
        <li class="nav-link"><a href="<?php echo e(route("student-dashboard")); ?>" class="text-white"><i class="fas fa-bars text-dark"></i> Dashboard</a></li>
        <?php endif; ?>
    </ul>
</div><?php /**PATH E:\Laravel-Project\project64\resources\views/components/mobile-menu.blade.php ENDPATH**/ ?>