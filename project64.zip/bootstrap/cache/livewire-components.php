<?php return array (
  'search-post' => 'App\\Http\\Livewire\\SearchPost',
);