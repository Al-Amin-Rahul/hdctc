@extends('front.master')

@section('title')
HDCTC - FAQ
@endsection

@section('body')
    <section>
        <div class="container pt-5 pb-5">
            <div class="alert alert-light c-blue font-weight-bold">
                Faq
            </div>
        </div>
    </section>
@endsection