<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Union extends Model
{
    //
}
